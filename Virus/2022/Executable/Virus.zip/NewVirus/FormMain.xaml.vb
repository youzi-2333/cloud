﻿Public Class FormMain
    Private Sub Me_Loaded(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Loaded
        Me.Hide()
    End Sub
End Class
