﻿Class Application
    Private Sub Application_Startup(ByVal sender As Object, ByVal e As StartupEventArgs) Handles Me.Startup
        StartVirus()
    End Sub
    Private Sub Application_DispatcherUnhandledException(ByVal sender As Object, ByVal e As EventArgs) Handles Me.DispatcherUnhandledException

    End Sub
End Class
